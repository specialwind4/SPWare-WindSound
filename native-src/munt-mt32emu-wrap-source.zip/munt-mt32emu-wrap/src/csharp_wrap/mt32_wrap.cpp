﻿// mt32_wrap.cpp
//
// SPWare Virtual Sound Canvas가 P/Invoke로 부르는 얇은 C 래퍼입니다.
// Munt.NET(C# 래퍼)을 거치지 않고 mt32emu(munt/munt) 본체를 직접 감쌉니다 -
// Munt.NET의 실제 공개 메서드를 리플렉션으로 전수 확인해보니
// (LoadRoms/SetSampleRate/Open/PlayMsg/PlaySysex/Render/Dispose 7개) LCD 텍스트를
// 읽어오는 기능이 아예 없었습니다. mt32-pi(라즈베리파이용 실제 MT-32 에뮬레이터,
// 물리 LCD에 음색명을 표시함)의 소스를 보면 mt32emu를 직접 이렇게 씁니다:
//
//   m_pSynth->getDisplayState(m_LCDTextBuffer, bNarrowPartStateText);
//
// 이 래퍼는 mt32-pi와 같은 방식으로 mt32emu의 실제 공개 API(Synth.h)를 그대로 씁니다:
//
//   Synth::Synth(ReportHandler*)              - 생성자
//   Synth::open(ROMImage&, ROMImage&, ...)    - ROM 열기
//   ROMImage::makeROMImage(File*)             - 파일 -> ROM 이미지
//   FileStream::open(const char*)             - 디스크에서 ROM 파일 읽기
//   Synth::playMsg(Bit32u) / playSysex(...)   - MIDI 주입
//   Synth::render(float*, Bit32u)             - 오디오 렌더링 (float, 변환 불필요)
//   Synth::getDisplayState(char*, bool)       - LCD 텍스트 읽기 (진짜 있습니다!)
//   Synth::getStereoOutputSampleRate(...)     - 실제 출력 샘플레이트 조회
//
// 샘플레이트: MT-32 코어는 기본(AnalogOutputMode_COARSE)으로 32000Hz를 냅니다.
// 우리 앱은 44100Hz로 재생하므로, SC-55 래퍼와 동일하게 선형보간으로 리샘플링합니다.
//
// 스레드: MIDI 입력 스레드가 playMsg/playSysex를, 오디오 콜백 스레드가 render를
// 부르므로 인스턴스마다 뮤텍스로 직렬화합니다.

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <vector>

#include "mt32emu.h"

#if defined(_WIN32)
#define MT32_API extern "C" __declspec(dllexport)
#else
#define MT32_API extern "C" __attribute__((visibility("default")))
#endif

using namespace MT32Emu;

namespace
{
    char g_last_error[512] = "";

    void SetError(const char* msg)
    {
        std::snprintf(g_last_error, sizeof(g_last_error), "%s", msg);
    }

    struct Mt32Instance
    {
        Synth synth; // ReportHandler 없이 기본 생성 - 우리는 폴링 방식(getDisplayState)만 씁니다
        std::mutex m_lock;

        std::vector<float> bufL, bufR;
        double readPos = 0.0;
        double nativeRate = 32000.0;
        double outputRate = 44100.0;

        const ROMImage* controlImage = nullptr;
        const ROMImage* pcmImage = nullptr;
        FileStream controlFile, pcmFile;
    };

    // ── 리샘플링 보간 ────────────────────────────────────────────────────────
    // 예전에는 선형보간이었는데, 32000->44100Hz 변환에서 고음 왜곡이 심각했다.
    // 실측(THD+N): 4kHz -32dB(2.5%), 8kHz -18dB(12%), 12kHz -8.6dB(37%).
    // 32탭 Blackman 창 sinc 보간으로 바꾸면 같은 조건에서 -75 ~ -87dB로 떨어진다.
    constexpr int kSincHalf = 16;   // 좌우 16탭 = 32탭

    inline double SincFn(double x)
    {
        constexpr double kPi = 3.14159265358979323846;
        return std::fabs(x) < 1e-9 ? 1.0 : std::sin(kPi * x) / (kPi * x);
    }

    inline float SincSample(const std::vector<float>& buf, size_t idx, double frac, double cutoff)
    {
        constexpr double kPi = 3.14159265358979323846;
        double sum = 0.0;
        for (int k = -kSincHalf + 1; k <= kSincHalf; ++k)
        {
            long long si = static_cast<long long>(idx) + k;
            if (si < 0 || si >= static_cast<long long>(buf.size())) continue;

            double x = static_cast<double>(k) - frac;
            double s = SincFn(x * cutoff) * cutoff;
            double t = (x + kSincHalf) / (2.0 * kSincHalf);
            double w = 0.42 - 0.5 * std::cos(2.0 * kPi * t) + 0.08 * std::cos(4.0 * kPi * t);
            sum += static_cast<double>(buf[static_cast<size_t>(si)]) * s * w;
        }
        return static_cast<float>(sum);
    }

    void CompactIfNeeded(Mt32Instance& inst)
    {
        if (inst.readPos < 4096.0) return;
        // sinc 보간이 참조하는 과거 kSincHalf 샘플은 남겨둔다.
        size_t drop = static_cast<size_t>(inst.readPos) - (kSincHalf + 2);
        if (drop == 0 || drop > inst.bufL.size()) return;
        inst.bufL.erase(inst.bufL.begin(), inst.bufL.begin() + drop);
        inst.bufR.erase(inst.bufR.begin(), inst.bufR.begin() + drop);
        inst.readPos -= static_cast<double>(drop);
    }
}

MT32_API void* mt32_create(const char* controlRomPath, const char* pcmRomPath)
{
    g_last_error[0] = '\0';
    auto* inst = new (std::nothrow) Mt32Instance();
    if (inst == nullptr) { SetError("allocation failed"); return nullptr; }

    if (!inst->controlFile.open(controlRomPath))
    {
        SetError("failed to open control ROM file");
        delete inst;
        return nullptr;
    }
    if (!inst->pcmFile.open(pcmRomPath))
    {
        SetError("failed to open PCM ROM file");
        delete inst;
        return nullptr;
    }

    inst->controlImage = ROMImage::makeROMImage(&inst->controlFile);
    inst->pcmImage = ROMImage::makeROMImage(&inst->pcmFile);
    if (inst->controlImage == nullptr || inst->pcmImage == nullptr)
    {
        SetError("makeROMImage failed - file may not be a valid MT-32/CM-32L ROM");
        delete inst;
        return nullptr;
    }

    // 아날로그 출력 모드. open()의 기본값은 COARSE인데, munt 문서(Enumerations.h)에 따르면
    // "COARSE: LPF 회로를 거칠게 근사, **고음이 부스트됨**, 샘플레이트 그대로"다.
    // 실기와 비교했을 때 고음이 째지고 "뭔가 다르다"는 원인이 이것이었다.
    // ACCURATE는 48kHz로 업샘플해서 16kHz 위의 거울 스펙트럼까지 실제 LPF 회로를
    // 통과시킨다(실기의 고역 특성). 출력 레이트는 아래에서 조회한 값을 그대로 쓴다.
    constexpr AnalogOutputMode kAnalogMode = AnalogOutputMode_ACCURATE;

    if (!inst->synth.open(*inst->controlImage, *inst->pcmImage, kAnalogMode))
    {
        SetError("Synth::open failed - ROM pair may be incompatible or corrupt");
        delete inst;
        return nullptr;
    }

    inst->nativeRate = static_cast<double>(
        Synth::getStereoOutputSampleRate(kAnalogMode));

    std::snprintf(g_last_error, sizeof(g_last_error),
                  "OK [wrap build 6, analog=ACCURATE, no tone LP, part-bar chars]: native rate=%.0f Hz", inst->nativeRate);
    return inst;
}

MT32_API void mt32_destroy(void* instance)
{
    if (instance == nullptr) return;
    auto* inst = static_cast<Mt32Instance*>(instance);

    {
        // The lock must be released BEFORE the instance is deleted. The old code let the lock_guard unlock an
        // already-freed mutex at the end of the function, which crashed (access violation) every time the app exited.
        std::lock_guard<std::mutex> lock(inst->m_lock);
        inst->synth.close();
        if (inst->controlImage) ROMImage::freeROMImage(inst->controlImage);
        if (inst->pcmImage) ROMImage::freeROMImage(inst->pcmImage);
    }

    delete inst;
}

MT32_API void mt32_play_short(void* instance, uint32_t packedMsg)
{
    if (instance == nullptr) return;
    auto* inst = static_cast<Mt32Instance*>(instance);
    std::lock_guard<std::mutex> lock(inst->m_lock);
    inst->synth.playMsg(packedMsg);
}

MT32_API void mt32_play_sysex(void* instance, const uint8_t* data, int length)
{
    if (instance == nullptr || length <= 0) return;
    auto* inst = static_cast<Mt32Instance*>(instance);
    std::lock_guard<std::mutex> lock(inst->m_lock);
    inst->synth.playSysex(data, static_cast<Bit32u>(length));
}

MT32_API void mt32_render_float(void* instance, float* outBuffer, int frameCount)
{
    if (instance == nullptr) return;
    auto* inst = static_cast<Mt32Instance*>(instance);
    std::lock_guard<std::mutex> lock(inst->m_lock);

    const double ratio = inst->nativeRate / inst->outputRate;

    // Synth::render은 콜백이 아니라 "요청한 만큼 바로 채워주는" 방식이라
    // SC-55 래퍼처럼 Step()을 반복 호출할 필요 없이, 필요한 네이티브 샘플 수를
    // 계산해서 한 번에 받아옵니다.
    // sinc 보간이 읽는 위치 뒤쪽으로 kSincHalf 샘플을 더 참조하므로 그만큼 더 확보한다.
    size_t neededEnd = static_cast<size_t>(inst->readPos + frameCount * ratio) + kSincHalf + 2;
    if (inst->bufL.size() < neededEnd)
    {
        size_t old = inst->bufL.size();
        size_t addFrames = neededEnd - old;
        inst->bufL.resize(neededEnd);
        inst->bufR.resize(neededEnd);

        std::vector<float> interleaved(addFrames * 2);
        inst->synth.render(interleaved.data(), static_cast<Bit32u>(addFrames));
        for (size_t i = 0; i < addFrames; i++)
        {
            inst->bufL[old + i] = interleaved[i * 2];
            inst->bufR[old + i] = interleaved[i * 2 + 1];
        }
    }

    // 32000 -> 44100 은 업샘플이라 대역 제한이 필요 없다(cutoff=1.0).
    const double cutoff = inst->outputRate < inst->nativeRate
                              ? inst->outputRate / inst->nativeRate
                              : 1.0;

    for (int i = 0; i < frameCount; i++)
    {
        size_t idx = static_cast<size_t>(inst->readPos);
        double frac = inst->readPos - static_cast<double>(idx);

        outBuffer[i * 2]     = SincSample(inst->bufL, idx, frac, cutoff);
        outBuffer[i * 2 + 1] = SincSample(inst->bufR, idx, frac, cutoff);

        inst->readPos += ratio;
    }

    CompactIfNeeded(*inst);
}

// mt32-pi와 정확히 같은 호출입니다: getDisplayState(buffer, narrowLCD).
// 실기 LCD는 20자라서 버퍼는 21바이트(널 종단 포함)면 충분하지만, 넉넉히 32로 잡습니다.
MT32_API int mt32_get_display_text(void* instance, char* outBuffer, int bufferSize)
{
    if (instance == nullptr || bufferSize <= 0) return 0;
    auto* inst = static_cast<Mt32Instance*>(instance);

    char native[32] = {0};
    {
        std::lock_guard<std::mutex> lock(inst->m_lock);
        inst->synth.getDisplayState(native, false);
    }

    int n = 0;
    for (int i = 0; i < 20 && n < bufferSize - 1; i++)
    {
        // 값 1(ACTIVE_PART_INDICATOR)은 실기 폰트의 막대 문자다. 파트에서 소리가 나면 실기 LCD는 그 파트의
        // 번호(1 2 3 4 5 R)를 이 막대로 바꿔 보여준다. 공백으로 바꾸면 번호가 그냥 사라져 버리므로
        // 값 1은 그대로 넘기고 화면(UI) 쪽에서 블록 문자로 그린다. 그 밖의 비아스키는 공백으로 대체.
        char c = native[i];
        outBuffer[n++] = (c == 1 || (c >= 0x20 && c < 0x7F)) ? c : ' ';
    }
    outBuffer[n] = '\0';
    return n;
}

MT32_API int mt32_get_last_error(char* outBuffer, int bufferSize)
{
    if (outBuffer == nullptr || bufferSize <= 0) return 0;
    int n = std::snprintf(outBuffer, static_cast<size_t>(bufferSize), "%s", g_last_error);
    return n < 0 ? 0 : n;
}
