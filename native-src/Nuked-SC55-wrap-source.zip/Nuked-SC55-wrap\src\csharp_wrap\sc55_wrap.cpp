﻿// sc55_wrap.cpp
//
// SPWare Virtual Sound Canvas가 P/Invoke로 부르는 얇은 C 래퍼입니다.
// nuked-sc55-backend(이 저장소의 실제 에뮬레이터 코어, src/backend/emu.h의
// Emulator 클래스)를 그대로 감싸기만 합니다 - 직접 확인한 실제 공개 API를
// 그대로 씁니다(추측으로 짠 게 아닙니다):
//
//   Emulator::Init(EMU_Options)               - rom_directory 지정, LCD는 끔(nullptr)
//   DetectRomsetsByHash / PickCompleteRomset   - ROM 폴더에서 세트 자동 인식
//   LoadRomset / Emulator::LoadRoms            - 실제 ROM 바이트 로드
//   Emulator::SetSampleCallback                - 오디오 프레임이 나올 때마다 콜백
//   Emulator::PostMIDI                         - MIDI 바이트 주입
//   Emulator::Step                             - 에뮬레이션을 한 스텝 전진
//   Emulator::GetLCD().LCD_Data[80]            - LCD 문자 코드(DDRAM) 원본
//
// 샘플레이트에 대해: SC-55mkII 코어는 고정된 자체 출력 주파수(약 66207Hz)로
// 샘플을 만듭니다. 우리 앱은 44100Hz로 재생하므로, 여기서 선형보간(linear
// interpolation)으로 간단히 리샘플링합니다. 정확도보다 "일단 정확한 피치로
// 들리게"가 목적이라 이 정도면 충분하고, 더 고품질이 필요하면 나중에 제대로 된
// 폴리페이즈 리샘플러로 바꾸면 됩니다.
//
// 스레드에 대해: MIDI 입력 스레드가 sc55_feed_midi를, 오디오 콜백 스레드가
// sc55_render_float를 부르므로, 인스턴스마다 뮤텍스 하나로 둘을 직렬화합니다.
// PostMIDI/Step을 여러 스레드에서 동시에 불러도 되는지 헤더만으로는 보장되지
// 않아서, 안전하게 가는 쪽을 택했습니다.

#include "emu.h"
#include "rom_io.h"
#include "rom.h"
#include "pcm.h"
#include "mcu.h"
#include "lcd.h"
#include "submcu.h"
#include "mcu_timer.h"
#include <new>

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <mutex>
#include <vector>

#if defined(_WIN32)
#define SC55_API extern "C" __declspec(dllexport)
#else
#define SC55_API extern "C" __attribute__((visibility("default")))
#endif

namespace
{
    // ── 리샘플링 보간 ────────────────────────────────────────────────────────
    // 예전에는 선형보간을 썼는데, 실측해보니 고음에서 왜곡이 심각했다
    // (66207->44100 변환 기준: 8kHz에서 -32.8dB=2.3%, 12kHz에서 -25dB=5.6%).
    // 32탭 Blackman 창 sinc 보간으로 바꾸면 같은 조건에서 -100dB 수준으로 떨어진다.
    // cutoff = outRate/inRate 로 두면 다운샘플 시 안티앨리어싱까지 이 필터가 겸한다
    // (그래서 따로 두었던 biquad 로우패스는 제거했다).
    constexpr int kSincHalf = 16;   // 좌우 16탭 = 32탭

    inline double SincFn(double x)
    {
        constexpr double kPi = 3.14159265358979323846;
        return std::fabs(x) < 1e-9 ? 1.0 : std::sin(kPi * x) / (kPi * x);
    }

    inline float SincSample(const std::vector<float>& buf, size_t idx, double frac, double cutoff)
    {
        constexpr double kPi = 3.14159265358979323846;
        double sum = 0.0;
        for (int k = -kSincHalf + 1; k <= kSincHalf; ++k)
        {
            long long si = static_cast<long long>(idx) + k;
            if (si < 0 || si >= static_cast<long long>(buf.size())) continue;

            double x = static_cast<double>(k) - frac;
            double s = SincFn(x * cutoff) * cutoff;
            double t = (x + kSincHalf) / (2.0 * kSincHalf);
            double w = 0.42 - 0.5 * std::cos(2.0 * kPi * t) + 0.08 * std::cos(4.0 * kPi * t);
            sum += static_cast<double>(buf[static_cast<size_t>(si)]) * s * w;
        }
        return static_cast<float>(sum);
    }

    // (참고) 예전에 쓰던 2차 Butterworth 로우패스(biquad).
    // 66207Hz -> 44100Hz로 선형보간 리샘플링(다운샘플링, ratio~1.5)하기 전에
    // 새 나이퀴스트(22050Hz)를 넘는 성분을 미리 죽여야 앨리어싱이 안 생깁니다.
    // 이게 없으면 22050~33103Hz 사이 성분이 11097~22050Hz로 접혀 들어와서
    // 실기에 없던 거친 히스/잡음처럼 들립니다(단음 테스트로는 고음 에너지가
    // 적어서 안 들리다가, 실제 곡의 심벌/고음 신스에서 두드러짐).
    struct Biquad
    {
        float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0;
        float x1 = 0, x2 = 0, y1 = 0, y2 = 0;

        void SetLowpass(double sampleRate, double cutoffHz, double q)
        {
            double w0 = 2.0 * 3.14159265358979323846 * cutoffHz / sampleRate;
            double cosw0 = std::cos(w0);
            double sinw0 = std::sin(w0);
            double alpha = sinw0 / (2.0 * q);

            double b0d = (1 - cosw0) / 2;
            double b1d = 1 - cosw0;
            double b2d = (1 - cosw0) / 2;
            double a0d = 1 + alpha;
            double a1d = -2 * cosw0;
            double a2d = 1 - alpha;

            b0 = static_cast<float>(b0d / a0d);
            b1 = static_cast<float>(b1d / a0d);
            b2 = static_cast<float>(b2d / a0d);
            a1 = static_cast<float>(a1d / a0d);
            a2 = static_cast<float>(a2d / a0d);
        }

        float Process(float x)
        {
            float y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
            x2 = x1; x1 = x;
            y2 = y1; y1 = y;
            return y;
        }
    };

    // Emulator는 LCD 백엔드를 받았을 때만 LCD 쓰기(LCD_Write)를 처리한다. 예전에는 nullptr을 줘서
    // LCD 정보를 전혀 못 읽었다(sc55_get_status_text도 늘 빈 값). 여기서는 화면을 직접 그리지 않고,
    // 앱이 sc55_get_lcd로 픽셀 버퍼를 가져다 자기 화면에 그린다.
    class WrapLcdBackend : public LCD_Backend
    {
    public:
        bool Start(lcd_t&) override { return true; }
        void Stop() override {}
        void Render() override {}
    };

    struct Sc55Instance
    {
        Emulator emu;
        WrapLcdBackend lcdBackend;
        std::mutex mutex;

        // emu.h 주석: "`all_info` should outlive the emulator instance."
        // 처음엔 이걸 sc55_create의 지역변수로 뒀는데, 그러면 함수가 끝나는 순간
        // 사라져서 에뮬레이터가 이미 해제된 메모리를 참조하게 됩니다. 인스턴스가
        // 들고 있도록 고쳤습니다.
        AllRomsetInfo all_info;

        std::vector<float> bufL;
        std::vector<float> bufR;
        double readPos = 0.0;       // bufL/bufR 안에서의 위치(리샘플링용, 소수점 포함)
        double nativeRate = 66207.52;
        double outputRate = 44100.0;

        // 안티앨리어싱 로우패스: 2단 직렬(4차 Butterworth, ~24dB/oct).
        // 처음엔 2차(12dB/oct) 하나만 썼는데, 감쇠가 약해서 걸러지다 만
        // 고음 성분이 오히려 가늘고 날카로운("째지는") 잡음으로 들린다는
        // 피드백을 받고 2단으로 강화함. Stage1/2의 Q는 4차 Butterworth를
        // 정확히 맞추는 표준값(0.5412, 1.3066) - 그냥 같은 Q를 두 번 쓰면
        // 컷오프 근처에서 응답이 처지는(maximally flat이 아닌) 필터가 됨.
        Biquad aaFilterL1, aaFilterR1, aaFilterL2, aaFilterR2;
    };

    // sc55_create가 왜 실패했는지 C#쪽에 알려주기 위한 버퍼.
    // 실패 원인이 "ROM 인식 실패"인지 "초기화 실패"인지 구분이 안 되면
    // 디버깅이 추측 게임이 되어버려서 추가했습니다.
    char g_last_error[512] = "";

    // 부팅에 돌릴 스텝 수. 0이면 아래 기본값을 씁니다.
    //
    // 이 저장소의 렌더러(R_RunReset)는 2400만 스텝을 돌립니다. 실측해보니
    // 400만=무음, 800만부터 정상 출력이라 안전 마진을 두고 1200만으로 잡았습니다
    // (PC에서 약 3초. 2400만이면 약 6초라 시작이 체감상 느립니다).
    // 문제가 생기면 sc55_set_boot_steps(24000000)으로 원래 값으로 되돌리세요.
    constexpr size_t kDefaultBootSteps = 12'000'000;
    size_t g_boot_steps = 0;

    void SetError(const char* msg)
    {
        std::snprintf(g_last_error, sizeof(g_last_error), "%s", msg);
    }

    void SampleCallback(void* userdata, const AudioFrame<int32_t>& frame)
    {
        auto* inst = static_cast<Sc55Instance*>(userdata);
        AudioFrame<float> f{};
        Normalize(frame, f);

        // backend/audio.h의 float용 Normalize는 int16용 경로보다 정확히 2배 크게 나온다.
        //   int16 : (in * 10386) >> 28        -> in = 8.469e8 에서 풀스케일(32767)
        //   float : in / 2^26 * 0.158483      -> 같은 in 에서 2.0  (±1.0 이어야 함)
        // 그대로 쓰면 믹서에 ±2.0짜리 신호가 들어가 마스터 볼륨을 웬만큼 내려도
        // 소프트 클리퍼가 상시 걸려 찌그러진다. 여기서 절반으로 맞춰준다.
        // (외부 저장소 헤더를 고치는 대신 우리 래퍼에서 보정)
        constexpr float kFloatNormalizeFix = 0.5f;
        f.left *= kFloatNormalizeFix;
        f.right *= kFloatNormalizeFix;

        // 안티앨리어싱은 sinc 보간의 cutoff가 겸하므로 여기서는 그대로 쌓기만 한다.
        inst->bufL.push_back(f.left);
        inst->bufR.push_back(f.right);
    }

    // bufL/bufR의 앞부분 중 이미 다 소비한 만큼을 잘라내서 메모리가 무한정
    // 늘어나지 않게 합니다. 보간에 필요한 여유(2샘플)는 남겨둡니다.
    void CompactIfNeeded(Sc55Instance& inst)
    {
        if (inst.readPos < 4096.0) return;
        // sinc 보간은 읽는 위치 앞쪽으로 kSincHalf 샘플의 과거를 참조하므로 남겨둔다.
        size_t drop = static_cast<size_t>(inst.readPos) - (kSincHalf + 2);
        if (drop == 0 || drop > inst.bufL.size()) return;
        inst.bufL.erase(inst.bufL.begin(), inst.bufL.begin() + drop);
        inst.bufR.erase(inst.bufR.begin(), inst.bufR.begin() + drop);
        inst.readPos -= static_cast<double>(drop);
    }
}

SC55_API void* sc55_create(const char* romDirectory)
{
    // 메시지는 전부 ASCII로 씁니다. DLL 안에 한글을 넣으면 MSVC 소스 인코딩과
    // C#의 UTF-8 디코딩이 어긋나 글자가 깨집니다.
    g_last_error[0] = '\0';

    auto* inst = new (std::nothrow) Sc55Instance();
    if (inst == nullptr)
    {
        SetError("allocation of Sc55Instance failed");
        return nullptr;
    }

    std::filesystem::path dir(romDirectory);

    if (!std::filesystem::exists(dir))
    {
        SetError("ROM directory does not exist");
        delete inst;
        return nullptr;
    }

    if (!DetectRomsetsByHash(dir, inst->all_info))
    {
        SetError("DetectRomsetsByHash failed - no known ROM hashes found in folder");
        delete inst;
        return nullptr;
    }

    Romset romset;
    if (!PickCompleteRomset(inst->all_info, romset))
    {
        SetError("PickCompleteRomset failed - ROMs recognized but set is incomplete");
        delete inst;
        return nullptr;
    }

    if (!LoadRomset(romset, inst->all_info))
    {
        SetError("LoadRomset failed - files found but could not be read");
        delete inst;
        return nullptr;
    }

    EMU_Options options{};
    options.rom_directory = dir;
    options.lcd_backend = &inst->lcdBackend; // LCD 처리를 켠다(픽셀은 sc55_get_lcd로 가져간다)

    if (!inst->emu.Init(options))
    {
        // Emulator::Init은 내부에서 bad_alloc만 잡아서 false를 돌려주므로,
        // 실패했다면 아래 다섯 덩어리 중 하나를 할당하지 못한 것입니다.
        // 어느 것이 얼마나 커서 실패했는지 직접 재서 알려줍니다.
        size_t total = sizeof(mcu_t) + sizeof(submcu_t) + sizeof(mcu_timer_t)
                     + sizeof(lcd_t) + sizeof(pcm_t);

        auto probe = [](size_t n) -> bool {
            void* p = ::operator new(n, std::nothrow);
            if (p) ::operator delete(p, std::nothrow);
            return p != nullptr;
        };

        std::snprintf(g_last_error, sizeof(g_last_error),
            "Emulator::Init failed (out of memory). "
            "sizes: mcu=%zu sub=%zu timer=%zu lcd=%zu pcm=%zu total=%zu bytes (%.1f MB). "
            "probe: mcu=%s lcd=%s pcm=%s total=%s",
            sizeof(mcu_t), sizeof(submcu_t), sizeof(mcu_timer_t),
            sizeof(lcd_t), sizeof(pcm_t), total, total / 1048576.0,
            probe(sizeof(mcu_t)) ? "ok" : "FAIL",
            probe(sizeof(lcd_t)) ? "ok" : "FAIL",
            probe(sizeof(pcm_t)) ? "ok" : "FAIL",
            probe(total) ? "ok" : "FAIL");

        delete inst;
        return nullptr;
    }

    if (!inst->emu.LoadRoms(romset, inst->all_info))
    {
        SetError("Emulator::LoadRoms failed - set complete but emulator could not load it");
        delete inst;
        return nullptr;
    }

    inst->emu.Reset();
    inst->nativeRate = static_cast<double>(PCM_GetOutputFrequency(inst->emu.GetPCM()));

    // 출력 나이퀴스트(outputRate/2 = 22050Hz) 바로 아래를 컷오프로 잡아서
    // 다운샘플링 시 접혀 들어올 고음역 성분을 미리 죽입니다. 4차 Butterworth를
    // 2개의 2차 biquad로 쪼갤 때 쓰는 표준 Q값(둘 다 같은 컷오프에서 직렬로).
    double cutoff = inst->outputRate / 2.0 * 0.85;
    const double kQ1 = 0.541196100146197;  // 4th-order Butterworth stage 1
    const double kQ2 = 1.306562964876377;  // 4th-order Butterworth stage 2
    inst->aaFilterL1.SetLowpass(inst->nativeRate, cutoff, kQ1);
    inst->aaFilterL2.SetLowpass(inst->nativeRate, cutoff, kQ2);
    inst->aaFilterR1.SetLowpass(inst->nativeRate, cutoff, kQ1);
    inst->aaFilterR2.SetLowpass(inst->nativeRate, cutoff, kQ2);

    // 실기 펌웨어를 부팅시킵니다. 이게 없으면 MIDI를 보내도 아무 소리가 안 납니다 -
    // 전원을 켜자마자 건반을 누른 것과 같은 상태이기 때문입니다.
    // 이 저장소의 렌더러(R_RunReset)도 정확히 같은 방식으로 2400만 스텝을 돌립니다.
    // 이 동안 나오는 샘플은 버리기 위해 콜백을 나중에 붙입니다.
    inst->emu.StartLCD();
    // 실기는 배터리 백업 SRAM(Backup On, 매뉴얼 p.37)에 마지막 설정을 저장해뒀다가 전원을 켤 때
    // 그대로 보여준다. LoadRoms()가 이미 ReadSRAM()으로 Roms\SC55mk2\memory.bin0을 복원해뒀으므로,
    // 백업이 있으면 GS 리셋을 보내지 않는다(안 그러면 방금 복원한 LEVEL/PAN 등을 리셋이 곧바로
    // 기본값으로 덮어써 버린다 - §2.40/§2.57에서 확인). 백업이 없으면(첫 실행 등) 지금처럼 GS 리셋.
    // 업스트림 Nuked-SC55의 standard/main.cpp도 같은 조건으로 판단한다.
    // (§2.59에서 MUTE 문제 때문에 이걸 의심해서 한 번 되돌렸었는데, §2.61에서 진짜 원인이 게임 쪽
    // GS Reset SysEx(실기 사양 - Mute Lock 없인 원래 그럼)라는 게 밝혀져서 이 SRAM 복원은 무죄로
    // 결론 내고 다시 적용한다.)
    if (!inst->emu.IsSRAMLoaded())
        inst->emu.PostSystemReset(EMU_SystemReset::GS_RESET);
    size_t steps = g_boot_steps > 0 ? g_boot_steps : kDefaultBootSteps;
    for (size_t i = 0; i < steps; ++i)
        inst->emu.Step();

    // 부팅이 끝난 뒤에 콜백을 붙여야 부팅 중 샘플이 버퍼에 쌓이지 않습니다.
    inst->emu.SetSampleCallback(SampleCallback, inst);

    std::snprintf(g_last_error, sizeof(g_last_error),
                  "OK: romset=%s, native rate=%.0f Hz", RomsetName(romset), inst->nativeRate);
    return inst;
}

// 부팅 스텝 수를 조절합니다. sc55_create 호출 전에 부르세요.
// 기본 2400만 스텝은 실기 부팅을 완전히 재현하지만 PC에서 몇 초가 걸립니다.
SC55_API void sc55_set_boot_steps(unsigned long long steps)
{
    g_boot_steps = static_cast<size_t>(steps);
}

// 마지막 sc55_create 호출의 결과 메시지를 돌려줍니다(성공 시에는 인식된 romset 이름).
SC55_API int sc55_get_last_error(char* outBuffer, int bufferSize)
{
    if (outBuffer == nullptr || bufferSize <= 0) return 0;
    int n = std::snprintf(outBuffer, static_cast<size_t>(bufferSize), "%s", g_last_error);
    return n < 0 ? 0 : n;
}

SC55_API void sc55_destroy(void* instance)
{
    delete static_cast<Sc55Instance*>(instance);
}

SC55_API void sc55_feed_midi(void* instance, const uint8_t* data, int length)
{
    if (instance == nullptr || length <= 0) return;
    auto* inst = static_cast<Sc55Instance*>(instance);
    std::lock_guard<std::mutex> lock(inst->mutex);
    inst->emu.PostMIDI(std::span<const uint8_t>(data, static_cast<size_t>(length)));
}

SC55_API void sc55_render_float(void* instance, float* outBuffer, int frameCount)
{
    if (instance == nullptr) return;
    auto* inst = static_cast<Sc55Instance*>(instance);
    std::lock_guard<std::mutex> lock(inst->mutex);

    const double ratio = inst->nativeRate / inst->outputRate;
    // 다운샘플(ratio>1)이면 새 나이퀴스트에 맞춰 대역을 제한한다(안티앨리어싱 겸용).
    const double cutoff = inst->outputRate < inst->nativeRate
                              ? inst->outputRate / inst->nativeRate
                              : 1.0;

    for (int i = 0; i < frameCount; i++)
    {
        // sinc 보간은 읽는 위치 뒤쪽으로 kSincHalf 샘플을 더 참조하므로 그만큼 더 채운다.
        while (static_cast<size_t>(inst->readPos) + kSincHalf + 1 >= inst->bufL.size())
            inst->emu.Step();

        size_t idx = static_cast<size_t>(inst->readPos);
        double frac = inst->readPos - static_cast<double>(idx);

        outBuffer[i * 2]     = SincSample(inst->bufL, idx, frac, cutoff);
        outBuffer[i * 2 + 1] = SincSample(inst->bufR, idx, frac, cutoff);

        inst->readPos += ratio;
    }

    CompactIfNeeded(*inst);
}

// 에뮬레이터가 그린 실제 LCD 화면(SC-55mkII는 741x268)을 BGRA(0xAARRGGBB) 픽셀로 복사해 준다.
// 부팅 배너, 펌웨어가 만드는 파트/악기 표시, 레벨 미터까지 실기 그대로다.
// LCD_Render는 lcd.mutex를 try_lock으로만 잡으므로(MCU가 LCD를 갱신 중이면 그 프레임은 건너뜀)
// 오디오 렌더링(inst->mutex)을 붙잡지 않는다. 성공하면 1, 버퍼가 작거나 준비 안 됐으면 0.
SC55_API int sc55_get_lcd(void* instance, uint32_t* outBgra, int capacityPixels, int* outWidth, int* outHeight)
{
    if (instance == nullptr || outBgra == nullptr || outWidth == nullptr || outHeight == nullptr) return 0;
    auto* inst = static_cast<Sc55Instance*>(instance);
    lcd_t& lcd = inst->emu.GetLCD();

    LCD_Render(lcd);

    size_t w = lcd.width, h = lcd.height;
    if (w == 0 || h == 0 || w > lcd_width_max || h > lcd_height_max) return 0;
    if (static_cast<size_t>(capacityPixels) < w * h) return 0;

    for (size_t y = 0; y < h; y++)
    {
        const uint32_t* src = lcd.buffer[y];
        uint32_t* dst = outBgra + y * w;
        for (size_t x = 0; x < w; x++)
        {
            uint32_t p = src[x];                // 0xAABBGGRR (R가 아래 바이트)
            uint32_t r = p & 0xFF, g = (p >> 8) & 0xFF, b = (p >> 16) & 0xFF;
            dst[x] = 0xFF000000u | (r << 16) | (g << 8) | b;
        }
    }
    *outWidth = static_cast<int>(w);
    *outHeight = static_cast<int>(h);
    return 1;
}

// 전면 버튼 한 개를 누르거나 뗀다. button은 mcu.h의 MCU_BUTTON_* 번호(0~31)이고, 에뮬레이터의 SDL 프론트엔드가
// 마우스로 하는 것과 똑같이 mcu.button_pressed 비트를 켜고 끈다(펌웨어가 버튼 행렬을 읽으면 그 비트를 본다).
// 원자적 변수라서 오디오 렌더링(inst->mutex)과 무관하게 호출해도 된다.
SC55_API void sc55_set_button(void* instance, int button, int pressed)
{
    if (instance == nullptr || button < 0 || button > 31) return;
    auto* inst = static_cast<Sc55Instance*>(instance);
    mcu_t& mcu = inst->emu.GetMCU();
    uint32_t v = mcu.button_pressed;
    if (pressed) v |= (1u << button);
    else         v &= ~(1u << button);
    mcu.button_pressed = v;
}

// 여러 버튼을 **같은 순간에** 바꾼다. mask에 있는 비트만 pressed 값으로 덮어쓴다.
// 실기 조작 중에는 PART [<]와 [>]를 "동시에" 눌러야 하는 것이 있는데(매뉴얼 P.43~44), 버튼을 하나씩 따로 켜면
// 그 사이에 펌웨어가 한 버튼만 눌린 것으로 먼저 처리해 버려서 동시 누름으로 인식하지 못한다.
SC55_API void sc55_set_buttons(void* instance, uint32_t mask, uint32_t pressed)
{
    if (instance == nullptr) return;
    auto* inst = static_cast<Sc55Instance*>(instance);
    mcu_t& mcu = inst->emu.GetMCU();
    mcu.button_pressed = (mcu.button_pressed & ~mask) | (pressed & mask);
}

// LCD 대비(1~16). 펌웨어의 "LCD Contrast" 설정(매뉴얼 P.44)이 실제로 쓰는 값이다. 앱이 종료할 때 읽어 저장하고,
// 다음 실행에서 부팅이 끝난 뒤 되돌려 준다. LCD_SetContrast가 범위를 1~16으로 잘라 준다.
SC55_API int sc55_get_lcd_contrast(void* instance)
{
    if (instance == nullptr) return 0;
    return static_cast<Sc55Instance*>(instance)->emu.GetLCD().contrast;
}

SC55_API void sc55_set_lcd_contrast(void* instance, int contrast)
{
    if (instance == nullptr) return;
    LCD_SetContrast(static_cast<Sc55Instance*>(instance)->emu.GetLCD(), static_cast<uint8_t>(contrast < 0 ? 0 : contrast));
}

// LCD_Data는 HD44780 호환 컨트롤러의 DDRAM(문자 코드 80바이트)입니다.
// 표준 아스키(0x20~0x7E) 범위는 그대로 글자로 옮기고, 그 밖(막대그래프용
// 커스텀 도트 문자 등)은 공백으로 채웁니다 - 실기 전용 폰트 매핑까지는
// 확인하지 못해서, 읽을 수 있는 글자만 정직하게 뽑아오는 선에서 그칩니다.
SC55_API int sc55_get_status_text(void* instance, char* outBuffer, int bufferSize)
{
    if (instance == nullptr || bufferSize <= 0) return 0;
    auto* inst = static_cast<Sc55Instance*>(instance);

    lcd_t& lcd = inst->emu.GetLCD();
    std::lock_guard<std::mutex> lcdLock(lcd.mutex);

    int n = 0;
    int max = static_cast<int>(sizeof(lcd.LCD_Data));
    for (int i = 0; i < max && n < bufferSize - 1; i++)
    {
        uint8_t c = lcd.LCD_Data[i];
        outBuffer[n++] = (c >= 0x20 && c < 0x7F) ? static_cast<char>(c) : ' ';
    }
    outBuffer[n] = '\0';
    return n;
}
