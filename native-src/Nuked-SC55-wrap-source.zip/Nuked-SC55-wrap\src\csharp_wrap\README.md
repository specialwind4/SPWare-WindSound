# sc55_wrap 빌드 방법

SPWare Virtual Sound Canvas가 P/Invoke로 부르는 `nuked_sc55_wrap.dll`을 만드는 타깃입니다.
`nuked-sc55-backend`(이 저장소의 실제 에뮬레이터 코어)만 링크하고, SDL2나 rtmidi는
전혀 필요 없습니다 — 그래서 전체 GUI 앱을 빌드할 때보다 훨씬 간단합니다.

## Windows (MSVC)

```
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release --target sc55_wrap
```

결과물: `build\Release\nuked_sc55_wrap.dll` (또는 `build\src\csharp_wrap\Release\` 등
제너레이터에 따라 위치가 다를 수 있습니다 — `dir /s nuked_sc55_wrap.dll`로 찾으세요).

이걸 SPWare.VirtualSoundCanvas 프로젝트의
`SPWare.VirtualSoundCanvas\Native\x64\nuked_sc55_wrap.dll` 로 복사하면 됩니다.

## 검증한 것 / 못한 것

- **한 것**: `sc55_wrap.cpp`를 이 저장소의 실제 헤더(emu.h, rom_io.h, pcm.h)에 대고
  `g++ -std=c++23 -fsyntax-only`로 문법·타입 체크를 통과시켰습니다. 함수 시그니처,
  구조체 필드명 전부 이 저장소의 실제 코드와 대조된 것이지 추측이 아닙니다.
- **못 한 것**: 실제 링크·실행까지는 이 환경에 Windows/MSVC 툴체인이 없어서 못 해봤습니다.
  `emu.cpp`/`mcu.cpp` 등 나머지 backend 구현체와 링크하는 단계에서 뭔가 더 나올 가능성은
  남아있습니다. 처음 빌드해보시고 에러가 나면 알려주세요.

## 리샘플링에 대해

SC-55mkII 코어는 약 66207Hz 고정 출력이라, 우리 앱의 44100Hz 재생과 안 맞습니다.
`sc55_wrap.cpp` 안에서 선형보간으로 간단히 리샘플링합니다 — 피치는 정확하게 맞지만
최고 음질은 아닙니다. 나중에 필요하면 제대로 된 폴리페이즈 리샘플러로 바꿀 수 있습니다.
